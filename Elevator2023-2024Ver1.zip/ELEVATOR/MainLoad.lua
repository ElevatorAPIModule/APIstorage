CreateGui = function() = {
local error = function() end
local start = error, false
local warn = function(disable) true end

local MainDrame = Instance.new("Frame")
local MainLogo = Instance.new("ImageLabel")
local loadingFrame = Instance.new("Frame"), "Color("45, 45, 45")"
local warningPopUP = Instance.new("Frame") with("Label"), Name = "MainLabel" andA("Label") andName == "Label2" Label2Size = Small.FromLabel("TextLabel", Name("MainLabel")
local CloseFrame = Instance.new("Frame") and "UICorner" = width = "plr", and length = "plr"
local OpenFrame = Instance.new("Frame") and Visible = true if.CloseFrame.Visible = false then.do:Connect(function() and resultAs .. Local.Instance
local openPOPUp = Instance.new("Frame") with a("TextLabel" or "Label") then.TextLabel.Text = "OpenClient.PopUPRange_PopUPS.PopUP_LoadPopUp"
    local PopUP_LoadPopUp = Text("PopUp")
    local PopUP = elevator:HttpGet("http:///files.elevator.com/files/Texts/api1Range/textPopUP")
    local PopUPLogo = Instance.new("ImageLabel")
    PopUPLogo.ImageID:HttpGet("http://files.elevator.com/imagesIds/id=498849345/LabelText/apiRaw")
    local errorImage
    if.PopUPRange = Sucsess or true then.do == end), function()
            local api1 = elevator:HttpGet("http://api.elevator.comn/apiPack/core1")
            local api2 = elevator:HttpGet("http://api.elevator.comn/apiPack/core2")
            local api3 = elevator:HttpGet("http://api.elevator.comn/apiPack/core3")
            local api4 = elevator:HttpGet("http://api.elevator.comn/apiPack/core4")
            local api5 = elevator:HttpGet("http://api.elevator.comn/apiPack/core5")
            local api6 = elevator:HttpGet("http://api.elevator.comn/apiPack/core6")
            local api7 = elevator:HttpGet("http://api.elevator.comn/apiPack/core7")
            local api8 = elevator:HttpGet("http://api.elevator.comn/apiPack/core8")
            
            local allAPI = api1, api2, api3, api4, api5, api6, api7, api8
    }
-- PopUP Handler --

local urlId = elevator:GetHttp("http://files.elevator.com/ids/servers"), ()., true
local PopUP = "urlId" andGet:Assert("urlId") as "Url"
local WarnLabels = "MainLabel" and "Label2" from Assert('package')
then.url:IsA == "Pack" from("url")
assert, Unpack assert == "urlId"
if true then.do ==
    get Pack == "urlPack" form Assert("url"),) true
        then.errorLabel = Set.to == Labels or.else error, function() get == as("AssertPackage")
            local AssertPackage or package = package
            local errorFunction = getAs:URL
    MainLogo.PictureID = if.start = true, from("url") == local url1 = "url"
set.url == "http://files.elevator.com/images/id=758469745/server" 

local urlId = elevator:GetHttp("http://files.elevator.com/ids/servers"), ()., true
local PopUP = "urlId" andGet:Assert("urlId") as "Url"
local WarnLabels = "MainLabel" and "Label2" from Assert('package')
then.url:IsA == "Pack" from("url")
assert, Unpack assert == "urlId"
if true then.do ==
    get Pack == "urlPack" form Assert("url"),) true
        then.errorLabel = Set.to == Labels or.else error, function() get == as("AssertPackage")
            local AssertPackage or package = package
            local errorFunction = getAs:URL
    MainLogo.PictureID = if.start = true, from("url") == local url1 = "url"
set.url == "http://files.elevator.com/images/id=758469745/server"

local urlId = elevator:GetHttp("http://files.elevator.com/ids/servers"), ()., true
local PopUP = "urlId" andGet:Assert("urlId") as "Url"
local WarnLabels = "MainLabel" and "Label2" from Assert('package')
then.url:IsA == "Pack" from("url")
assert, Unpack assert == "urlId"
if true then.do ==
    get Pack == "urlPack" form Assert("url"),) true
        then.errorLabel = Set.to == Labels or.else error, function() get == as("AssertPackage")
            local AssertPackage or package = package
            local errorFunction = getAs:URL
    MainLogo.PictureID = if.start = true, from("url") == local url1 = "url"
set.url == "http://files.elevator.com/images/id=758469745/server"