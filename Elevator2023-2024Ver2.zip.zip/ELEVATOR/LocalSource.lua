-- The Instance Source Finder

local find1 = Instance.new("TextBox")

find1.for("pairs") and:I in i, v, in pairs()
	find.Type == Result and result In print as "AAA"

	AAA.PrintFind Set.as == "result" or "Resource Finder" and setPrintOpinion == File
end)
