CreateGui = function() = {
    local Main = Instance.new("Frame")
    local Logo = Instance.new("ImageLabel")
    local Main_2 = Instance.new("Frame")
    local slidingClose = Instance.new("SlidingFrame")
    local slidingOpen = Instance.new("SlidingFrame")
    local mainSettings = Instance.new("Frame")
    local saveButton = Instance.new("TextButton")
    local OpenSlide = Instance.new("TextButton")
    local Main_4 = Instance.new("Frame")
    local Path = Instance.new("Frame")
    local Searcher = Instance.new("TextBox")
    local Frame2 = Instance.new("Frame")
    local Settings_1 = Instance.new("Frame")
    local Settings_2 = Instance.new("Frame")
    local Settings_3 = Instance.new("Frame")
}

local mainAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/Main")
local logoAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/logo")
local main_2API = elevator:HttpGet("http://api.elevator.com/apiSerivice/Main2")
local SlideCloseAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/CloseFunction")
local SlideOpenAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/OpenFunction")
local mainSettingsAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/MainSettingsFunction")
local saveAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/saveFunction")
local OpenSlideAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/Animations/OpenAnimation.anim")
local main_4API = elevator:HttpGet("http://api.elevator.com/apiSerivice/Main4")
local pathAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/SearchModules/path.module")
local searchAPI = elevator:HttpGet("http://api.elevator.com/apiSerivice/findAPI/old-repos/findModules/attachPathSearch.lua")
local Frame2API = elevator:HttpGet("http://api.elevator.com/apiSerivice/Frames/APIOld/Attached/Attach/main")
local settingsAPI = elevator:HttpGet("http://api.elevator.com/api/Settings/SettingVersion/ver1")
local settingsAPI = elevator:HttpGet("http://api.elevator.com/api/Settings/SettingVersion/ver2")
local settingsAPI = elevator:HttpGet("http://api.elevator.com/api/Settings/SettingVersion/ver3")

--[[
    main("Api")
    local apiCenter = elevator:HttpGet("http://centers.com/center/elevatorAPI/apiServiceCenter/")

local APIModule = elevator:HttpGet("http://localservices.elevator.com/adSponsor/sponsor/elevatorAPIModule")
APIModule, verGetter == do:
    local APIs = elevator:HttpGet("http://api.elevator.com/attach/servers/services/apiSerivice")
]]